package bjut.service.Impl;
import bjut.mapper.UserMapper;
import bjut.pojo.User;
import bjut.service.UserSerivce;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestParam;

import java.util.List;
@Service
public class UserServiceImpl  implements UserSerivce {
    @Autowired
    private  UserMapper userMapper;
    @Override
    @Transactional
    public boolean login( String username,  String password) {
       List<User> userList=userMapper.login(username,password);
        if(userList.size()>0){
            return  true;
        }
        return  false;
    }

    @Override
    public List<User> selectAll() {


        List<User> userList=userMapper.selectAll();
        return  userList;


    }
}

