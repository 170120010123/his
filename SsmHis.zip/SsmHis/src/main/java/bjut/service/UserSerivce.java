package bjut.service;

import bjut.pojo.User;

import java.util.List;

public interface UserSerivce {

    public boolean  login(String username, String password);
    public List<User> selectAll();
}
