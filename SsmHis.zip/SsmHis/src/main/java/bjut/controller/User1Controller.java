package bjut.controller;

import bjut.pojo.User;
import bjut.service.UserSerivce;
import bjut.utils.Result;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseBody;
import java.util.List;


@Controller
@ResponseBody
@RequestMapping("/user")
public class User1Controller {

@Autowired
UserSerivce userSerivce;
    @GetMapping("/selectall")
public Result selectAll(){
    List<User> userList = userSerivce.selectAll();
    return Result.success(userList);


}

}
