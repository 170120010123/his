package bjut.pojo;

public class Token {

    public  String token;
    public String getToken() {
        return token;
    }

    public void setToken(String token) {
        this.token = token;
    }

}
